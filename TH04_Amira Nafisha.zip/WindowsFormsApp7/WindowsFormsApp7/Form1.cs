﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        private List<string> countries = new List<string>();
        private List<string> positions = new List<string>();
        private List<Team> teams = new List<Team>();

        public Form1()
        {
            InitializeComponent();
            comboBox_ChooseCountry.Text = string.Empty;
            teamAdded = false; // Inisialisasi variabel teamAdded
            InitializeData();
            comboBox_ChooseCountry.DataSource = countries;
            comboBox_PlayerPosition.DataSource = positions;
            RefreshTeamList(); //memastikan bahwa data tim ditampilkan saat aplikasi dimulai
        }

        private void InitializeData()
        {
            // Data untuk combo box Country
            countries.Add("England");
            countries.Add("Germany");

            // Data untuk combo box Position
            positions.Add("GK");
            positions.Add("DF");
            positions.Add("MF");
            positions.Add("FW");

            // Inisialisasi tim awal
            Team team1 = new Team("Manchester United", "England", "Manchester");
            team1.Players.Add(new Player("01", "David De Gea", "GK"));
            team1.Players.Add(new Player("02", "Victor Lindelof", "DF"));
            team1.Players.Add(new Player("04", "Phil Jones", "DF"));
            team1.Players.Add(new Player("05", "Harry Maguire", "DF"));
            team1.Players.Add(new Player("06", "Lisandro Martinez", "DF"));
            team1.Players.Add(new Player("08", "Bruno Fernandez", "MF"));
            team1.Players.Add(new Player("09", "Anthony Martial", "FW"));
            team1.Players.Add(new Player("10", "Marcus Rashford", "FW"));
            team1.Players.Add(new Player("12", "Tyrell Malancia", "MF"));
            team1.Players.Add(new Player("14", "Christian Eriksen", "MF"));
            team1.Players.Add(new Player("18", "Casemiro", "MF"));
            teams.Add(team1);

            Team team2 = new Team("Chelsea", "England", "Chelsea");
            team2.Players.Add(new Player("01", "Kepa Arrizabalaga", "GK"));
            team2.Players.Add(new Player("04", "Benoit Badiashile", "DF"));
            team2.Players.Add(new Player("05", "Enzo Femandez", "MF"));
            team2.Players.Add(new Player("06", "Thiago Silva", "DF"));
            team2.Players.Add(new Player("07", "N`Golo Kante", "MF"));
            team2.Players.Add(new Player("08", "Mateo Kovacic", "MF"));
            team2.Players.Add(new Player("09", "Pierre-Emerick Aubameyang", "FW"));
            team2.Players.Add(new Player("10", "Christian Pulisic", "MF"));
            team2.Players.Add(new Player("11", "Joao Felix", "FW"));
            team2.Players.Add(new Player("12", "Ruben Loftus-Cheek", "MF"));
            team2.Players.Add(new Player("17", "Raheem Sterling", "MF"));
            teams.Add(team2);

            Team team3 = new Team("Bayern Munich", "Germany", "Bayern");
            team3.Players.Add(new Player("01", "Manuel Neuer", "GK"));
            team3.Players.Add(new Player("02", "Dayot Upamecano", "DF"));
            team3.Players.Add(new Player("04", "Matthijs de Ligt", "DF"));
            team3.Players.Add(new Player("05", "Benjamin Pavard", "DF"));
            team3.Players.Add(new Player("06", "Joshua Kimmich", "MF"));
            team3.Players.Add(new Player("07", "Serge Gnabry", "FW"));
            team3.Players.Add(new Player("08", "Leon Goretzka", "MF"));
            team3.Players.Add(new Player("10", "Leroy Sane", "FW"));
            team3.Players.Add(new Player("14", "Paul Wanner", "MF"));
            team3.Players.Add(new Player("21", "Lucas Hernandez", "DF"));
            team3.Players.Add(new Player("25", "Thomas Muller", "FW"));
            teams.Add(team3);
        }

        private void btn_AddAddingTeam_Click(object sender, EventArgs e)
        {
            if (teamAdded)
            {
                MessageBox.Show("Team can only be added once.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string teamName = textBox_TeamName.Text;
            string teamCountry = comboBox_ChooseCountry.SelectedItem?.ToString();
            string teamCity = textBox_TeamCity.Text;

            if (string.IsNullOrEmpty(teamName) || string.IsNullOrEmpty(teamCountry) || string.IsNullOrEmpty(teamCity))
            {
                MessageBox.Show("Please fill in all fields to add a team.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Periksa apakah tim sudah ada
            if (teams.Any(team => team.TeamName.Equals(teamName)))
            {
                MessageBox.Show("Team already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Tambahkan tim baru
            Team newTeam = new Team(teamName, teamCountry, teamCity);
            teams.Add(newTeam);

            // Perbarui combo box Country
            if (!countries.Contains(teamCountry))
            {
                countries.Add(teamCountry);

                comboBox_ChooseCountry.DataSource = null;
                comboBox_ChooseCountry.DataSource = countries;
                comboBox_ChooseCountry.SelectedItem = teamCountry; // Pilih negara yang baru ditambahkan
            }
            teamAdded = true;
        }

        private void comboBox_ChooseTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_ChooseTeam.SelectedIndex != -1)
            {
                string selectedTeamName = comboBox_ChooseTeam.SelectedItem.ToString();
                Team selectedTeam = teams.Find(team => team.TeamName.Equals(selectedTeamName));
                if (selectedTeam != null)
                {
                    DisplayPlayers(selectedTeam); //Menampilkan pemain tim yang dipilih
                }
            }
        }

        private void comboBox_ChooseCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCountry = comboBox_ChooseCountry.SelectedItem.ToString();

            comboBox_ChooseTeam.Items.Clear(); // Bersihkan item-item sebelumnya

            // Tambahkan tim-tim dari negara yang dipilih
            foreach (Team team in teams)
            {
                if (team.TeamCountry.Equals(selectedCountry))
                {
                    comboBox_ChooseTeam.Items.Add(team.TeamName);
                }
            }
            // Hapus tim selain Bayern Munich dari comboBox_ChooseTeam jika negara yang dipilih adalah Germany
            if (selectedCountry.Equals("Germany"))
            {
                for (int i = comboBox_ChooseTeam.Items.Count - 1; i >= 0; i--)
                {
                    string teamName = comboBox_ChooseTeam.Items[i].ToString();
                    if (!teamName.Equals("Bayern Munich"))
                    {
                        comboBox_ChooseTeam.Items.RemoveAt(i);
                    }
                }
            }
        }

        private void DisplayPlayers(Team team)
        {
            listBox_ListOfPlayer.Items.Clear();
            foreach (Player player in team.Players)
            {
                listBox_ListOfPlayer.Items.Add(player);
            }
        }

        private void RefreshTeamList()
        {
            comboBox_ChooseTeam.Items.Clear();
            foreach (Team team in teams)
            {
                comboBox_ChooseTeam.Items.Add(team.TeamName);
            }
        }

        private bool teamAdded = false; // Variabel untuk melacak apakah tim sudah ditambahkan

        private void btn_AddAddingPlayer_Click(object sender, EventArgs e)
        {
            if (comboBox_ChooseTeam.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a team first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string playerName = textBox_PlayerName.Text;
            string playerNumber = textBox_PlayerNumber.Text;
            string playerPosition = comboBox_PlayerPosition.SelectedItem.ToString();

            if (string.IsNullOrEmpty(playerName) || string.IsNullOrEmpty(playerNumber) || string.IsNullOrEmpty(playerPosition))
            {
                MessageBox.Show("Please fill in all fields to add a player.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Team selectedTeam = teams[comboBox_ChooseTeam.SelectedIndex];

            // Periksa apakah nomor pemain sudah ada dalam tim
            if (selectedTeam.Players.Any(player => player.PlayerNum == playerNumber))
            {
                MessageBox.Show("Player with this number already exists in the team.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Tambahkan pemain baru sesuai urutan nomor pemain
            InsertPlayerInOrder(selectedTeam.Players, new Player(playerNumber, playerName, playerPosition));
            RefreshPlayerList(selectedTeam);

            listBox_ListOfPlayer.Sorted = true;
        }
        private void InsertPlayerInOrder(List<Player> players, Player newPlayer)
        {
            // Temukan posisi tempat pemain baru akan disisipkan
            int index = 0;
            foreach (Player player in players)
            {
                int currentPlayerNum;
                int newPlayerNum;

                if (int.TryParse(player.PlayerNum, out currentPlayerNum) && int.TryParse(newPlayer.PlayerNum, out newPlayerNum))
                {
                    if (currentPlayerNum > newPlayerNum)
                    {
                        break;
                    }
                }
                index++;
            }
            // Sisipkan pemain baru sesuai posisi yang telah ditentukan
            players.Insert(index, newPlayer);
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (comboBox_ChooseTeam.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a team first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Team selectedTeam = teams[comboBox_ChooseTeam.SelectedIndex];
            if (selectedTeam.Players.Count < 11)
            {
                MessageBox.Show("Team must have at least 11 players.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (listBox_ListOfPlayer.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a player to remove.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Periksa apakah ada item yang dipilih di listBox_ListOfPlayer
            if (listBox_ListOfPlayer.SelectedIndex != -1)
            {
                // Hapus pemain dari list pemain tim
                Player selectedPlayer = selectedTeam.Players[listBox_ListOfPlayer.SelectedIndex];
                selectedTeam.Players.Remove(selectedPlayer);

                // Hapus item dari listBox_ListOfPlayer
                listBox_ListOfPlayer.Items.RemoveAt(listBox_ListOfPlayer.SelectedIndex);

                // Refresh tampilan list pemain
                RefreshPlayerList(selectedTeam);
            }
            else
            {
                MessageBox.Show("Please select a player to remove.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshPlayerList(Team team)
        {
            listBox_ListOfPlayer.Items.Clear();
            foreach (Player player in team.Players)
            {
                listBox_ListOfPlayer.Items.Add(player);
            }
        }

        public class Team
        {
            public string TeamName = "";
            public string TeamCountry = "";
            public string TeamCity = "";
            public List<Player> Players = new List<Player>();

            public Team(string name, string country, string city)
            {
                TeamName = name;
                TeamCountry = country;
                TeamCity = city;
                Players = new List<Player>();
            }

            public override string ToString()
            {
                return TeamName;
            }
        }

        public class Player
        {
            public string PlayerName = "";
            public string PlayerNum = "";
            public string PlayerPos = "";

            public Player(string name, string num, string pos)
            {
                PlayerName = name;
                PlayerNum = num;
                PlayerPos = pos;
            }

            public override string ToString()
            {
                return $"({PlayerName}) {PlayerNum}, {PlayerPos}";
            }
        }
    }
}

